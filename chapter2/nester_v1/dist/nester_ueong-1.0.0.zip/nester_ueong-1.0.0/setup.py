from distutils.core import setup

setup( 
        name         = 'nester_ueong', 
        version      = '1.0.0', 
        py_modules   = ['nester'],
        author       = 'ueong',
        author_email = 'dnfod@me.com',
        url          = '',
        description  = 'headfirst example',
     )
